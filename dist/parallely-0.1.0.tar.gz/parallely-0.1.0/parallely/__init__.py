__version__ = '0.1.0'

from parallely.coroutines import asynced
from parallely.threads import threaded
from parallely.processes import parallel